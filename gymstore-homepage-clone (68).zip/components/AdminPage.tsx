import React, { useState } from 'react';
import { Product, User, Order, OrderStatus, Theme, Article, Brand } from '../types';
import AddProductModal, { ProductFormData } from './AddProductModal';
import DeleteConfirmationModal from './DeleteConfirmationModal';
import AddKnowledgeModal from './AddKnowledgeModal';
import KnowledgeManagementView from './KnowledgeManagementView';
import BrandManagementView from './BrandManagementView';
import AddBrandModal from './AddBrandModal';

// Icons
const DashboardIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 10h18M3 14h18m-9-4v8m-7 0h14a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z" /></svg>;
const ProductsIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 8h14M5 8a2 2 0 110-4h14a2 2 0 110 4M5 8v10a2 2 0 002 2h10a2 2 0 002-2V8m-9 4h4" /></svg>;
const OrdersIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-3 7h3m-3 4h3m-6-4h.01M9 16h.01" /></svg>;
const BrandsIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" /></svg>;
const KnowledgeIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.246 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" /></svg>;
const EyeIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" /></svg>;
const LogoutIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" /></svg>;
const PaletteIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M7 21a4 4 0 01-4-4V5a2 2 0 012-2h4a2 2 0 012 2v12a4 4 0 01-4 4zm0 0h12a2 2 0 002-2v-4a2 2 0 00-2-2h-2.343M11 7.343l1.657-1.657a2 2 0 012.828 0l2.829 2.829a2 2 0 010 2.828l-8.486 8.485M7 17h.01" /></svg>;

type AdminView = 'dashboard' | 'products' | 'orders' | 'brands' | 'knowledge';

interface AdminPageProps {
  currentUser: User;
  onLogout: () => void;
  onViewSite: () => void;
  products: Product[];
  onAddProduct: (product: Product) => void;
  onUpdateProduct: (product: Product) => void;
  onDeleteProduct: (productId: number) => void;
  onToggleFeatured: (productId: number) => void;
  orders: Order[];
  onUpdateOrderStatus: (orderId: string, status: OrderStatus) => void;
  supplementArticles: Article[];
  nutritionArticles: Article[];
  onAddArticle: (article: Omit<Article, 'id' | 'date'>) => void;
  onUpdateArticle: (article: Article) => void;
  onDeleteArticle: (articleId: number) => void;
  totalRevenue: number;
  productRevenueData: any;
  theme: Theme;
  setTheme: (theme: Theme) => void;
  brands: Brand[];
  onAddBrand: (brandData: Omit<Brand, 'id'>) => void;
  onUpdateBrand: (brand: Brand) => void;
  onDeleteBrand: (brandId: number) => void;
  onToggleFeaturedBrand: (brandId: number) => void;
}

const AdminPage: React.FC<AdminPageProps> = (props) => {
  const [activeView, setActiveView] = useState<AdminView>('products');

  // Product Modal State
  const [isProductModalOpen, setIsProductModalOpen] = useState(false);
  const [productToEdit, setProductToEdit] = useState<Product | null>(null);

  // Brand Modal State
  const [isBrandModalOpen, setIsBrandModalOpen] = useState(false);
  const [brandToEdit, setBrandToEdit] = useState<Brand | null>(null);

  // Knowledge Modal State
  const [isKnowledgeModalOpen, setIsKnowledgeModalOpen] = useState(false);
  const [articleToEdit, setArticleToEdit] = useState<Article | null>(null);

  // Delete Modal State
  const [itemToDelete, setItemToDelete] = useState<{ id: number | string; name: string; type: 'product' | 'article' | 'brand' } | null>(null);
  
  // Handlers for Products
  const handleAddProduct = (formData: ProductFormData) => {
      const newProduct: Product = {
          ...formData,
          id: Date.now(),
          images: [formData.image],
          rating: 0,
          reviews: 0,
          inStock: formData.stockQuantity > 0,
          isFeatured: false,
          sold: 0,
          productReviews: [],
      };
      props.onAddProduct(newProduct);
      setIsProductModalOpen(false);
  };

  const handleUpdateProduct = (formData: ProductFormData) => {
      if (!productToEdit) return;
      const updatedProduct: Product = {
          ...productToEdit,
          ...formData,
          images: [formData.image],
          inStock: formData.stockQuantity > 0,
      };
      props.onUpdateProduct(updatedProduct);
      setIsProductModalOpen(false);
      setProductToEdit(null);
  };

  const handleDeleteConfirmed = () => {
    if (!itemToDelete) return;
    if (itemToDelete.type === 'product') {
        props.onDeleteProduct(itemToDelete.id as number);
    } else if (itemToDelete.type === 'article') {
        props.onDeleteArticle(itemToDelete.id as number);
    } else if (itemToDelete.type === 'brand') {
        props.onDeleteBrand(itemToDelete.id as number);
    }
    setItemToDelete(null);
  };

  const renderView = () => {
    // This is a simplified version. Ideally, these would be separate components.
    switch (activeView) {
      case 'products':
        return (
            <div>
              <header className="flex justify-between items-center mb-6">
                <h1 className="text-3xl font-bold">Quản lý Sản phẩm</h1>
                <button onClick={() => { setProductToEdit(null); setIsProductModalOpen(true); }} className="bg-[var(--admin-button-bg)] text-[var(--admin-button-text)] font-bold py-2 px-4 rounded-lg">Thêm sản phẩm</button>
              </header>
              <div className="bg-[var(--admin-bg-card)] p-4 rounded-lg">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b border-[var(--admin-border-color)]">
                      <th className="p-3 text-left">Sản phẩm</th>
                      <th className="p-3 text-left">Giá</th>
                      <th className="p-3 text-left">Kho</th>
                      <th className="p-3 text-left">Hành động</th>
                    </tr>
                  </thead>
                  <tbody>
                    {props.products.map(p => (
                      <tr key={p.id} className="border-b border-[var(--admin-border-color)] last:border-0">
                        <td className="p-3 flex items-center gap-3"><img src={p.images[0]} className="w-10 h-10 rounded-md object-cover" />{p.name}</td>
                        <td className="p-3">{p.price.toLocaleString('vi-VN')}₫</td>
                        <td className="p-3">{p.stockQuantity}</td>
                        <td className="p-3">
                          <button onClick={() => { setProductToEdit(p); setIsProductModalOpen(true); }} className="text-blue-500 mr-2">Sửa</button>
                          <button onClick={() => setItemToDelete({ id: p.id, name: p.name, type: 'product' })} className="text-red-500">Xóa</button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
        )
      case 'orders':
        return (
          <div>
            <h1 className="text-3xl font-bold mb-6">Quản lý Đơn hàng</h1>
            <div className="bg-[var(--admin-bg-card)] p-4 rounded-lg">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-[var(--admin-border-color)]">
                    <th className="p-3 text-left">Mã ĐH</th>
                    <th className="p-3 text-left">Khách hàng</th>
                    <th className="p-3 text-left">Tổng tiền</th>
                    <th className="p-3 text-left">Trạng thái</th>
                  </tr>
                </thead>
                <tbody>
                  {props.orders.map(o => (
                    <tr key={o.id} className="border-b border-[var(--admin-border-color)] last:border-0">
                      <td className="p-3">{o.id}</td>
                      <td className="p-3">{o.customer.name}</td>
                      <td className="p-3">{o.total.toLocaleString('vi-VN')}₫</td>
                      <td className="p-3">
                        <select
                          value={o.status}
                          onChange={(e) => props.onUpdateOrderStatus(o.id, e.target.value as OrderStatus)}
                          className="bg-transparent border border-[var(--admin-border-color)] rounded-md p-1"
                        >
                          <option>Chờ xác nhận</option>
                          <option>Đang xử lý</option>
                          <option>Đang giao hàng</option>
                          <option>Hoàn thành</option>
                          <option>Đã Hủy</option>
                          <option>Trả hàng</option>
                        </select>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )
      case 'brands':
        return (
          <BrandManagementView
            brands={props.brands}
            onAddNew={() => { setBrandToEdit(null); setIsBrandModalOpen(true); }}
            onEdit={(brand) => { setBrandToEdit(brand); setIsBrandModalOpen(true); }}
            onDelete={(brand) => setItemToDelete({ id: brand.id, name: brand.name, type: 'brand' })}
            onToggleFeatured={props.onToggleFeaturedBrand}
          />
        );
      case 'knowledge':
        return (
          <KnowledgeManagementView
            supplementArticles={props.supplementArticles}
            nutritionArticles={props.nutritionArticles}
            onAddNew={() => { setArticleToEdit(null); setIsKnowledgeModalOpen(true); }}
            onEdit={(article) => { setArticleToEdit(article); setIsKnowledgeModalOpen(true); }}
            onDelete={(article) => setItemToDelete({ id: article.id, name: article.title, type: 'article' })}
          />
        );
      case 'dashboard':
      default:
        return <div>
             <h1 className="text-3xl font-bold mb-6">Dashboard</h1>
             <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="bg-[var(--admin-bg-card)] p-4 rounded-lg">
                    <h2 className="font-bold">Tổng doanh thu</h2>
                    <p className="text-2xl">{props.totalRevenue.toLocaleString('vi-VN')}₫</p>
                </div>
                <div className="bg-[var(--admin-bg-card)] p-4 rounded-lg">
                    <h2 className="font-bold">Doanh thu (tuần)</h2>
                    <p className="text-2xl">{props.productRevenueData.weekly.total.toLocaleString('vi-VN')}₫</p>
                </div>
                <div className="bg-[var(--admin-bg-card)] p-4 rounded-lg">
                    <h2 className="font-bold">Doanh thu (tháng)</h2>
                    <p className="text-2xl">{props.productRevenueData.monthly.total.toLocaleString('vi-VN')}₫</p>
                </div>
             </div>
            </div>;
    }
  };

  const navItems = [
    { key: 'dashboard', label: 'Dashboard', icon: <DashboardIcon /> },
    { key: 'products', label: 'Sản phẩm', icon: <ProductsIcon /> },
    { key: 'orders', label: 'Đơn hàng', icon: <OrdersIcon /> },
    { key: 'brands', label: 'Thương hiệu', icon: <BrandsIcon /> },
    { key: 'knowledge', label: 'Kiến thức', icon: <KnowledgeIcon /> },
  ];

  return (
    <div className="min-h-screen bg-[var(--admin-bg-main)] text-[var(--admin-text-main)] flex">
      <aside className="w-64 bg-[var(--admin-bg-card)] p-4 flex flex-col">
        <h1 className="text-2xl font-bold text-center mb-8">GYMSUP <span className="text-[var(--admin-text-accent)]">Admin</span></h1>
        <nav className="flex-grow">
          <ul>
            {navItems.map(item => (
              <li key={item.key}>
                <button
                  onClick={() => setActiveView(item.key as AdminView)}
                  className={`w-full flex items-center space-x-3 p-3 rounded-lg text-left transition-colors mb-2 ${activeView === item.key ? 'bg-[var(--admin-button-bg)] text-[var(--admin-button-text)]' : 'hover:bg-[var(--admin-bg-hover)]'}`}
                >
                  {item.icon}
                  <span>{item.label}</span>
                </button>
              </li>
            ))}
          </ul>
        </nav>
        <div className="border-t border-[var(--admin-border-color)] pt-4">
          <p className="font-semibold">{props.currentUser.name}</p>
          <p className="text-sm text-[var(--admin-text-secondary)]">{props.currentUser.role}</p>
        </div>
      </aside>

      <div className="flex-1 flex flex-col">
        <header className="bg-[var(--admin-bg-card)] p-4 flex justify-end items-center gap-4">
             <button onClick={props.onViewSite} className="flex items-center gap-2 text-sm hover:text-[var(--admin-text-accent)]"><EyeIcon/> Xem trang web</button>
             <button onClick={props.onLogout} className="flex items-center gap-2 text-sm hover:text-[var(--admin-text-accent)]"><LogoutIcon/> Đăng xuất</button>
        </header>
        <main className="flex-1 p-8 overflow-y-auto">
          {renderView()}
        </main>
      </div>

      <AddProductModal 
        isOpen={isProductModalOpen}
        onClose={() => setIsProductModalOpen(false)}
        onAddProduct={handleAddProduct}
        onUpdateProduct={handleUpdateProduct}
        productToEdit={productToEdit}
        brands={props.brands}
      />
      <AddBrandModal
        isOpen={isBrandModalOpen}
        onClose={() => setIsBrandModalOpen(false)}
        onAddBrand={(brandData) => { props.onAddBrand(brandData); setIsBrandModalOpen(false); }}
        onUpdateBrand={(brand) => { props.onUpdateBrand(brand); setIsBrandModalOpen(false); }}
        brandToEdit={brandToEdit}
      />
      <AddKnowledgeModal
        isOpen={isKnowledgeModalOpen}
        onClose={() => setIsKnowledgeModalOpen(false)}
        onAddArticle={(article) => { props.onAddArticle(article); setIsKnowledgeModalOpen(false); }}
        onUpdateArticle={(article) => { props.onUpdateArticle(article); setIsKnowledgeModalOpen(false); }}
        articleToEdit={articleToEdit}
      />
      <DeleteConfirmationModal
        isOpen={!!itemToDelete}
        onClose={() => setItemToDelete(null)}
        onConfirm={handleDeleteConfirmed}
        itemName={itemToDelete?.name || ''}
        itemType={itemToDelete?.type}
      />
    </div>
  );
};

export default AdminPage;

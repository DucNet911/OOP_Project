import React from 'react';
import { Brand } from '../types';

const AddIcon: React.FC<{ className?: string }> = ({ className = 'w-4 h-4' }) => (
    <svg className={className} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={3} stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" d="M12 4.5v15m7.5-7.5h-15" /></svg>
);

const StarIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg className={className} xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor">
        <path fillRule="evenodd" d="M10.788 3.21c.448-1.077 1.976-1.077 2.424 0l2.082 5.007 5.404.433c1.164.093 1.636 1.545.749 2.305l-4.117 3.527 1.257 5.273c.271 1.136-.964 2.033-1.96 1.425L12 18.354 7.373 21.18c-.996.608-2.231-.29-1.96-1.425l1.257-5.273-4.117-3.527c-.887-.76-.415-2.212.749-2.305l5.404-.433 2.082-5.007z" clipRule="evenodd" />
    </svg>
);

interface BrandManagementViewProps {
    brands: Brand[];
    onEdit: (brand: Brand) => void;
    onDelete: (brand: Brand) => void;
    onAddNew: () => void;
    onToggleFeatured: (brandId: number) => void;
}

const BrandManagementView: React.FC<BrandManagementViewProps> = ({ brands, onEdit, onDelete, onAddNew, onToggleFeatured }) => {
    return (
        <>
            <header className="flex flex-col sm:flex-row justify-between sm:items-center mb-8 gap-4">
                <h1 className="text-3xl font-bold">Quản lý Thương hiệu</h1>
                <button 
                    onClick={onAddNew}
                    className="bg-[var(--admin-button-bg)] text-[var(--admin-button-text)] font-bold py-2.5 px-5 rounded-lg hover:opacity-90 transition-opacity flex items-center justify-center space-x-2"
                >
                    <AddIcon />
                    <span>Thêm thương hiệu</span>
                </button>
            </header>
            
            <div className="bg-[var(--admin-bg-card)] p-6 rounded-2xl shadow-sm">
                <div className="overflow-x-auto">
                    <table className="w-full text-sm text-left">
                        <thead className="text-xs text-[var(--admin-text-secondary)] uppercase border-b border-[var(--admin-border-color)]">
                            <tr>
                                <th scope="col" className="px-6 py-3">Thương hiệu</th>
                                <th scope="col" className="px-6 py-3">Nổi bật</th>
                                <th scope="col" className="px-6 py-3">Hành động</th>
                            </tr>
                        </thead>
                        <tbody>
                            {brands.map((brand) => (
                                <tr key={brand.id} className="border-b border-[var(--admin-border-color)] hover:bg-[var(--admin-bg-hover)]">
                                    <td className="px-6 py-4 font-medium flex items-center space-x-3">
                                        <img src={brand.logo} alt={brand.name} className="w-24 h-12 rounded-md object-contain bg-white p-1 flex-shrink-0"/>
                                        <span>{brand.name}</span>
                                    </td>
                                    <td className="px-6 py-4">
                                        <button onClick={() => onToggleFeatured(brand.id)} className="text-gray-400 hover:text-yellow-400">
                                            <StarIcon className={`w-5 h-5 ${brand.isFeatured ? 'text-yellow-400' : 'text-gray-600'}`} />
                                        </button>
                                    </td>
                                    <td className="px-6 py-4 flex items-center space-x-3">
                                        <button onClick={() => onEdit(brand)} className="font-medium text-[var(--admin-text-accent)] hover:underline">Sửa</button>
                                        <button onClick={() => onDelete(brand)} className="font-medium text-red-500 hover:underline">Xóa</button>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </div>
        </>
    );
};

export default BrandManagementView;

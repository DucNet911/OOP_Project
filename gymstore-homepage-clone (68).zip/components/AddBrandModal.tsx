import React, { useState, useEffect } from 'react';
import { Brand } from '../types';

export interface BrandFormData {
    name: string;
    logo: string;
    isFeatured: boolean;
}

interface AddBrandModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAddBrand: (brandData: Omit<Brand, 'id'>) => void;
  onUpdateBrand: (brand: Brand) => void;
  brandToEdit: Brand | null;
}

const AddBrandModal: React.FC<AddBrandModalProps> = ({ isOpen, onClose, onAddBrand, onUpdateBrand, brandToEdit }) => {
  const [formData, setFormData] = useState<BrandFormData>({ name: '', logo: '', isFeatured: false });
  const [error, setError] = useState('');

  const isEditMode = !!brandToEdit;

  useEffect(() => {
    if (isOpen) {
      if (isEditMode && brandToEdit) {
        setFormData({ name: brandToEdit.name, logo: brandToEdit.logo, isFeatured: brandToEdit.isFeatured });
      } else {
        setFormData({ name: '', logo: '', isFeatured: false });
      }
      setError('');
    }
  }, [isOpen, brandToEdit, isEditMode]);

  if (!isOpen) return null;

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value, type, checked } = e.target;
    setFormData(prev => ({ ...prev, [name]: type === 'checkbox' ? checked : value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name.trim()) { setError('Tên thương hiệu là bắt buộc.'); return; }
    if (!formData.logo.trim()) { setError('URL logo là bắt buộc.'); return; }
    try { new URL(formData.logo.trim()); } catch (_) { setError('Vui lòng nhập URL logo hợp lệ.'); return; }
    setError('');

    if (isEditMode && brandToEdit) {
      onUpdateBrand({ ...brandToEdit, ...formData });
    } else {
      onAddBrand(formData);
    }
    onClose();
  };
  
  const inputStyles = "w-full bg-[var(--admin-bg-hover)] border border-[var(--admin-border-color)] rounded-lg py-2.5 px-4 focus:outline-none focus:ring-2 ring-[var(--admin-text-accent)]";

  return (
    <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center animate-fade-in" onClick={onClose}>
      <div className="bg-[var(--admin-bg-card)] rounded-2xl shadow-xl w-full max-w-lg p-8" onClick={e => e.stopPropagation()}>
        <h2 className="text-2xl font-bold mb-6">{isEditMode ? 'Sửa thương hiệu' : 'Thêm thương hiệu mới'}</h2>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label htmlFor="name" className="block text-sm font-medium text-[var(--admin-text-secondary)] mb-1">Tên thương hiệu</label>
            <input type="text" id="name" name="name" value={formData.name} onChange={handleChange} className={inputStyles} placeholder="ví dụ: Optimum Nutrition" />
          </div>
          <div>
            <label htmlFor="logo" className="block text-sm font-medium text-[var(--admin-text-secondary)] mb-1">URL Logo</label>
            <input type="text" id="logo" name="logo" value={formData.logo} onChange={handleChange} className={inputStyles} placeholder="https://example.com/logo.png" />
          </div>
          <div>
            <label className="flex items-center space-x-3 cursor-pointer">
              <input
                type="checkbox"
                name="isFeatured"
                checked={formData.isFeatured}
                onChange={handleChange}
                className="h-5 w-5 rounded bg-[var(--admin-bg-hover)] border-[var(--admin-border-color)] text-[var(--admin-text-accent)] focus:ring-[var(--admin-text-accent)] focus:ring-offset-[var(--admin-bg-card)]"
              />
              <span className="text-[var(--admin-text-main)]">Đánh dấu là thương hiệu nổi bật</span>
            </label>
          </div>
          
          {error && <p className="text-red-500 text-sm text-center pt-2">{error}</p>}

          <div className="flex justify-end items-center space-x-4 pt-4">
            <button type="button" onClick={onClose} className="py-2 px-5 text-sm font-bold text-[var(--admin-text-secondary)] hover:text-[var(--admin-text-main)] transition-colors">Hủy</button>
            <button type="submit" className="bg-[var(--admin-button-bg)] text-[var(--admin-button-text)] font-bold py-2.5 px-6 rounded-lg hover:opacity-90 transition-opacity">
              {isEditMode ? 'Cập nhật' : 'Thêm'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default AddBrandModal;

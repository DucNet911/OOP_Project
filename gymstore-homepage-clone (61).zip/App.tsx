import React, { useState, useCallback, useEffect, useMemo } from 'react';
import { CartProvider } from './contexts/CartContext';
import { Product, Theme, User, Order, OrderStatus, CartItem, Review, Article, Brand } from './types';
import Header from './components/Header';
import Footer from './components/Footer';
import HomePage from './components/HomePage';
import ProductPage from './components/ProductPage';
import CategoryPage from './components/CategoryPage';
import CheckoutPage from './components/CheckoutPage';
import CartSidebar from './components/CartSidebar';
import AuthModal from './components/AuthModal';
import Chatbot from './components/Chatbot';
import { navLinks, allProducts as initialProducts, supplementArticles as initialSupplementArticles, nutritionArticles as initialNutritionArticles, brands as initialBrands } from './constants';
import BrandsPage from './components/BrandsPage';
import AdminPage from './components/AdminPage';
import AccountPage from './components/AccountPage';
import OrderHistoryPage from './components/OrderHistoryPage';
import InfoPage from './components/InfoPage';
import KnowledgeListPage from './components/KnowledgeListPage';
import QuickAddModal from './components/QuickAddModal';

// Mock Data for initial orders
const initialOrders: Order[] = [
  {
    id: 'GS12345',
    date: '15/07/2023',
    status: 'Hoàn thành',
    total: 1850000,
    items: [
      { ...initialProducts.find(p => p.id === 1)!, quantity: 1, size: '5Lbs', flavor: 'Double Rich Chocolate' },
    ],
    customer: { name: 'Nguyễn Văn An', email: 'an.nguyen@example.com', phone: '0901234567', address: '123 Đường A, Quận B, TP. HCM' },
    paymentStatus: 'Đã thanh toán',
    paymentMethod: 'card',
  },
  {
    id: 'GS12340',
    date: '10/07/2023',
    status: 'Đang xử lý',
    total: 2700000,
    items: [
      { ...initialProducts.find(p => p.id === 7)!, quantity: 1, flavor: 'Icy Blue Razz' },
      { ...initialProducts.find(p => p.id === 5)!, quantity: 1, flavor: 'Chocolate' },
    ],
    customer: { name: 'Trần Thị Bích', email: 'bich.tran@example.com', phone: '0912345678', address: '456 Đường C, Quận D, Hà Nội' },
    paymentStatus: 'Chưa thanh toán',
    paymentMethod: 'cod',
  },
    {
    id: 'GS12346',
    date: '16/07/2023',
    status: 'Đang giao hàng',
    total: 950000,
    items: [
      { ...initialProducts.find(p => p.id === 7)!, quantity: 1, flavor: 'Fruit Punch' },
    ],
    customer: { name: 'Lê Minh', email: 'minh.le@example.com', phone: '0911111111', address: '111 Đường X, Quận Y, TP. HCM' },
    paymentStatus: 'Đã thanh toán',
    paymentMethod: 'card',
  },
  {
    id: 'GS12347',
    date: '17/07/2023',
    status: 'Chờ xác nhận',
    total: 1950000,
    items: [
      { ...initialProducts.find(p => p.id === 2)!, quantity: 1, size: '5Lbs', flavor: 'Chocolate Fudge' },
    ],
    customer: { name: 'Phạm Thị Hoa', email: 'hoa.pham@example.com', phone: '0922222222', address: '222 Đường Z, Quận W, Hà Nội' },
    paymentStatus: 'Chưa thanh toán',
    paymentMethod: 'cod',
  },
  {
    id: 'GS12348',
    date: '18/07/2023',
    status: 'Đã Hủy',
    total: 450000,
    items: [
      { ...initialProducts.find(p => p.id === 9)!, quantity: 1 },
    ],
    customer: { name: 'Hoàng Văn Nam', email: 'nam.hoang@example.com', phone: '0933333333', address: '333 Đường U, Quận V, Đà Nẵng' },
    paymentStatus: 'Chưa thanh toán',
    paymentMethod: 'cod',
  },
  {
    id: 'GS12349',
    date: '19/07/2023',
    status: 'Trả hàng',
    total: 1650000,
    items: [
      { ...initialProducts.find(p => p.id === 5)!, quantity: 1, flavor: 'Vanilla' },
    ],
    customer: { name: 'Vũ Thị Lan', email: 'lan.vu@example.com', phone: '0944444444', address: '4